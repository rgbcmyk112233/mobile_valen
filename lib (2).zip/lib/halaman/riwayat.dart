import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../tema/warna.dart';

class RiwayatScreen extends StatefulWidget {
  final int userId;
  const RiwayatScreen({super.key, required this.userId});

  @override
  State<RiwayatScreen> createState() => _RiwayatScreenState();
}

class _RiwayatScreenState extends State<RiwayatScreen> {
  List riwayat = [];
  bool loading = true;

  // ✅ Format Rupiah Lokal — tanpa file tambahan
  String formatRupiah(int number) {
    return "Rp ${number.toString().replaceAllMapped(RegExp(r'(\d)(?=(\d{3})+(?!\d))'), (Match m) => "${m[1]}.")}";
  }

  Future<void> ambilRiwayat() async {
    const url =
        "https://api.sheety.co/bbb8b4389560e0f66169374c4062700b/nakamerch/riwayat";

    try {
      final res = await http.get(Uri.parse(url));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final semua = data["riwayat"] as List;

        setState(() {
          riwayat = semua.where((e) => e["userId"] == widget.userId).toList();
          loading = false;
        });
      } else {
        setState(() => loading = false);
      }
    } catch (e) {
      print("Error riwayat: $e");
      setState(() => loading = false);
    }
  }

  @override
  void initState() {
    super.initState();
    ambilRiwayat();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: WarnaTema.softGrey,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            // ✅ HEADER
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Image.asset("assets/gambar/logo.png", height: 45),
                      const SizedBox(width: 10),
                      const Spacer(),
                      const Text(
                        "Riwayat Pembelian",
                        style: TextStyle(
                          fontSize: 20,
                          color: WarnaTema.oceanBlue,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  const Divider(thickness: 1, color: Colors.black12),
                ],
              ),
            ),

            const SizedBox(height: 6),

            // ✅ LIST RIWAYAT
            Expanded(
              child: loading
                  ? const Center(child: CircularProgressIndicator())
                  : riwayat.isEmpty
                      ? const Center(
                          child: Text(
                            "Belum ada riwayat pembelian",
                            style: TextStyle(fontSize: 16),
                          ),
                        )
                      : ListView.builder(
                          padding: const EdgeInsets.all(12),
                          itemCount: riwayat.length,
                          itemBuilder: (context, i) {
                            final r = riwayat[i];

                            return Container(
                              margin: const EdgeInsets.only(bottom: 12),
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(12),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black12.withOpacity(0.05),
                                    blurRadius: 6,
                                    offset: const Offset(0, 3),
                                  ),
                                ],
                              ),
                              child: Row(
                                children: [
                                  ClipRRect(
                                    borderRadius: BorderRadius.circular(10),
                                    child: Image.network(
                                      r["gambar"],
                                      width: 70,
                                      height: 70,
                                      fit: BoxFit.cover,
                                    ),
                                  ),

                                  const SizedBox(width: 12),

                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          r["namaProduk"],
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          style: const TextStyle(
                                            fontSize: 16,
                                          ),
                                        ),
                                        const SizedBox(height: 4),
                                        Text(
                                          "Jumlah: ${r["qty"]}",
                                          style: const TextStyle(fontSize: 14),
                                        ),
                                        const SizedBox(height: 2),
                                        Text(
                                          formatRupiah(r["totalHarga"]),
                                          style: const TextStyle(
                                            color: Colors.green,
                                          ),
                                        ),
                                        const SizedBox(height: 4),
                                        Text(
                                          r["tanggal"],
                                          style: TextStyle(
                                            fontSize: 12,
                                            color: Colors.grey[600],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
            ),
          ],
        ),
      ),
    );
  }
}
