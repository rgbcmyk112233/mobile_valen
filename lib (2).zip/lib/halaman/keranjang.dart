import 'package:flutter/material.dart';
import '../tema/warna.dart';

class KeranjangItem {
  final String nama;
  final String gambar;
  int jumlah;
  double harga;
  bool dipilih;

  KeranjangItem({
    required this.nama,
    required this.gambar,
    required this.jumlah,
    required this.harga,
    this.dipilih = false,
  });
}

class KeranjangScreen extends StatefulWidget {
  static List<KeranjangItem> keranjang = []; // ✅ keranjang global

  const KeranjangScreen({super.key});

  @override
  State<KeranjangScreen> createState() => _KeranjangScreenState();
}

class _KeranjangScreenState extends State<KeranjangScreen> {
  double hitungTotal() {
    double total = 0;
    for (var item in KeranjangScreen.keranjang) {
      if (item.dipilih) total += item.harga * item.jumlah;
    }
    return total;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: WarnaTema.softGrey,
      body: SafeArea(
        child: Column(
          children: [
            // ✅ HEADER mirip toko.dart
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Image.asset(
                        "assets/gambar/logo.png",
                        height: 45,
                      ),
                      const SizedBox(width: 10),
                      const Spacer(),
                      const Text(
                        "Keranjang",
                        style: TextStyle(
                          fontSize: 22,
                          color: WarnaTema.oceanBlue,
                          letterSpacing: 1.2,
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 6),
                  const Divider(thickness: 1, color: Colors.black12),

                  TextButton.icon(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.arrow_back_rounded, color: WarnaTema.pirateBlack),
                    label: const Text(
                      "Kembali",
                      style: TextStyle(
                        color: WarnaTema.pirateBlack,
                        fontSize: 16,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 10),

            // ✅ List Keranjang
            Expanded(
              child: KeranjangScreen.keranjang.isEmpty
                  ? const Center(child: Text("Keranjangmu masih kosong"))
                  : ListView.builder(
                      padding: const EdgeInsets.all(12),
                      itemCount: KeranjangScreen.keranjang.length,
                      itemBuilder: (context, i) {
                        var item = KeranjangScreen.keranjang[i];

                        return Container(
                          margin: const EdgeInsets.only(bottom: 12),
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(12),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black12,
                                blurRadius: 4,
                              )
                            ],
                          ),
                          child: Row(
                            children: [
                              Checkbox(
                                value: item.dipilih,
                                onChanged: (val) {
                                  setState(() => item.dipilih = val!);
                                },
                              ),

                              ClipRRect(
                                borderRadius: BorderRadius.circular(12),
                                child: Image.network(
                                  item.gambar,
                                  width: 70,
                                  height: 70,
                                  fit: BoxFit.cover,
                                ),
                              ),
                              const SizedBox(width: 10),

                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(item.nama,
                                        style: const TextStyle(
                                            fontSize: 16)),
                                    Text("Rp ${item.harga.toStringAsFixed(0)}"),
                                    Row(
                                      children: [
                                        IconButton(
                                          icon: const Icon(Icons.remove_circle_outline),
                                          onPressed: () {
                                            if (item.jumlah > 1) {
                                              setState(() => item.jumlah--);
                                            }
                                          },
                                        ),
                                        Text("${item.jumlah}"),
                                        IconButton(
                                          icon: const Icon(Icons.add_circle_outline),
                                          onPressed: () {
                                            setState(() => item.jumlah++);
                                          },
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),

                              IconButton(
                                icon: const Icon(Icons.delete_forever, color: Colors.red),
                                onPressed: () {
                                  setState(() {
                                    KeranjangScreen.keranjang.removeAt(i);
                                  });
                                },
                              ),
                            ],
                          ),
                        );
                      },
                    ),
            ),

            // ✅ Footer Total & Checkout
            Container(
              padding: const EdgeInsets.all(12),
              decoration: const BoxDecoration(
                color: Colors.white,
                boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 5)],
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      "Total: Rp ${hitungTotal().toStringAsFixed(0)}",
                      style: const TextStyle(
                        fontSize: 18,
                        color: WarnaTema.oceanBlue,
                      ),
                    ),
                  ),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: WarnaTema.strawHatRed,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    onPressed: () {
                      if (hitungTotal() == 0) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text("Pilih produk dulu")),
                        );
                        return;
                      }

                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text("Checkout berhasil!")),
                      );
                    },
                    child: const Text("Checkout"),
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
