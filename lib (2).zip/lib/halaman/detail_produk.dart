import 'package:flutter/material.dart';
import '../tema/warna.dart';
import '../layanan/api_produk.dart';
import 'keranjang.dart';
import 'login.dart'; // pastikan nama & folder sama


class DetailProduk extends StatefulWidget {
  final Produk produk;
  const DetailProduk({super.key, required this.produk});

  @override
  State<DetailProduk> createState() => _DetailProdukState();
}

class _DetailProdukState extends State<DetailProduk> {
  int jumlah = 1;
  bool showJumlah = false;
  String selectedCurrency = "IDR";

  // ❗ sementara login palsu, nanti ganti dengan SharedPreferences kamu
  Future<bool> cekLogin() async {
    bool isLoggedIn = false; // TODO: ganti sesuai login kamu
    return isLoggedIn;
  }

  void showLoginDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        title: const Text("Kamu belum login ya?"),
        content: const Text("Login dulu yu, biar bisa tambah ke keranjang & checkout"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Tutup", style: TextStyle(color: Colors.red)),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const LoginScreen()),
              );
            },
            child: const Text("Login Disini"),
          ),

        ],
      ),
    );
  }

  // 💱 Fungsi Konversi Mata Uang
  double convertCurrency(double price, String currency) {
    if (currency == "JPY") return price / 120;
    if (currency == "USD") return price / 15500;
    return price;
  }

  String formatCurrency(double value, String currency) {
    if (currency == "JPY") return "¥${value.toStringAsFixed(0)}";
    if (currency == "USD") return "\$${value.toStringAsFixed(2)}";
    return "Rp ${value.toStringAsFixed(0)}";
  }

  @override
  Widget build(BuildContext context) {
    final p = widget.produk;

    return Scaffold(
      backgroundColor: WarnaTema.softGrey,
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(120),
        child: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Image.asset("assets/gambar/logo.png", height: 32),
                        const SizedBox(width: 10),
                      ],
                    ),
                    IconButton(
                      icon: const Icon(Icons.shopping_cart, color: WarnaTema.pirateBlack),
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => const KeranjangScreen()),
                        );
                      },
                    ),
                  ],
                ),
              ),
              const Divider(thickness: 1, color: Colors.black12),
              Align(
                alignment: Alignment.centerLeft,
                child: TextButton.icon(
                  onPressed: () => Navigator.pop(context),
                  icon: const Icon(Icons.arrow_back_rounded, color: WarnaTema.pirateBlack),
                  label: const Text(
                    "Kembali",
                    style: TextStyle(color: WarnaTema.pirateBlack, fontSize: 16),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),

      body: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(16),
                      child: Image.network(
                        p.gambar,
                        height: 260,
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          const Icon(Icons.store_mall_directory,
                              size: 20, color: Colors.black54),
                          const SizedBox(width: 6),
                          Text(
                            "Lokasi: ${p.lokasi ?? "Tidak tersedia"}",
                            style: const TextStyle(fontSize: 14, color: Colors.black87),
                          ),
                        ],
                      ),

                      DropdownButton<String>(
                        value: selectedCurrency,
                        items: const [
                          DropdownMenuItem(value: "IDR", child: Text("IDR")),
                          DropdownMenuItem(value: "JPY", child: Text("JPY")),
                          DropdownMenuItem(value: "USD", child: Text("USD")),
                        ],
                        onChanged: (val) {
                          setState(() => selectedCurrency = val!);
                        },
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),

                  Text(p.namaProduk,
                      style: const TextStyle(
                          fontSize: 22, color: WarnaTema.pirateBlack)),
                  const SizedBox(height: 4),

                  Text(
                    formatCurrency(
                      convertCurrency(p.harga.toDouble(), selectedCurrency),
                      selectedCurrency,
                    ),
                    style: const TextStyle(fontSize: 20, color: WarnaTema.oceanBlue),
                  ),

                  const SizedBox(height: 12),
                  const Divider(),
                  const SizedBox(height: 12),

                  const Text("Deskripsi",
                      style: TextStyle(fontSize: 18, color: WarnaTema.pirateBlack)),
                  const SizedBox(height: 6),
                  Text(
                    p.deskripsi,
                    style: const TextStyle(fontSize: 15, height: 1.5),
                  ),
                ],
              ),
            ),
          ),

          Container(
            padding: const EdgeInsets.all(16),
            decoration: const BoxDecoration(color: Colors.white, boxShadow: [
              BoxShadow(blurRadius: 6, color: Colors.black12)
            ]),
            child: Column(
              children: [
                if (showJumlah)
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      IconButton(
                        onPressed: () {
                          if (jumlah > 1) setState(() => jumlah--);
                        },
                        icon: const Icon(Icons.remove_circle_outline, color: WarnaTema.pirateBlack),
                      ),
                      Text("$jumlah", style: const TextStyle(fontSize: 18)),
                      IconButton(
                        onPressed: () => setState(() => jumlah++),
                        icon: const Icon(Icons.add_circle_outline, color: WarnaTema.pirateBlack),
                      ),
                    ],
                  ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    SizedBox(
                      width: 60,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: WarnaTema.oceanBlue,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                        onPressed: () async {
                          bool login = await cekLogin();
                          if (!login) {
                            showLoginDialog();
                            return;
                          }

                          setState(() => showJumlah = !showJumlah);
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(showJumlah
                                  ? "Pilih jumlah produk"
                                  : "Ditambahkan ke keranjang"),
                            ),
                          );
                        },
                        child: const Icon(Icons.shopping_cart),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: WarnaTema.strawHatRed,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                        onPressed: () async {
                          bool login = await cekLogin();
                          if (!login) {
                            showLoginDialog();
                            return;
                          }

                          setState(() => showJumlah = !showJumlah);
                        },
                        child: const Text("Beli Sekarang"),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
