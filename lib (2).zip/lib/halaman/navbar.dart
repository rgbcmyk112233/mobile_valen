import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../tema/warna.dart';
import 'beranda.dart';
import 'keranjang.dart';
import 'riwayat.dart';
import 'profil.dart';
import 'login.dart'; // ✅ tambahkan

class BottomNav extends StatefulWidget {
  const BottomNav({super.key});

  @override
  State<BottomNav> createState() => _MainBottomNavState();
}

class _MainBottomNavState extends State<BottomNav> {
  int _currentIndex = 0;
  String? _loggedEmail;

  final List<Widget> _pagesLogged = [
    const BerandaScreen(),
    const KeranjangScreen(),
    RiwayatScreen(userId: 0),
    const ProfilScreen(),
  ];

  final List<Widget> _pagesGuest = [
    const BerandaScreen(),
    const SizedBox(), // nanti diarahkan ke login
    const SizedBox(),
    const SizedBox(),
  ];

  @override
  void initState() {
    super.initState();
    _checkLogin();
  }

  Future<void> _checkLogin() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _loggedEmail = prefs.getString('logged_email');
    });
  }

  void _onNavTap(int index) {
    // Dashboard selalu bisa
    if (index == 0) {
      setState(() => _currentIndex = index);
      return;
    }

    // Kalau belum login, arahkan ke login
    if (_loggedEmail == null) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const LoginScreen()),
      );
      return;
    }

    // Kalau sudah login, buka halaman
    setState(() => _currentIndex = index);
  }

  @override
  Widget build(BuildContext context) {
    final pages = _loggedEmail != null ? _pagesLogged : _pagesGuest;

    return Scaffold(
      backgroundColor: WarnaTema.softGrey,
      body: pages[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        selectedItemColor: WarnaTema.oceanBlue,
        unselectedItemColor: Colors.grey,
        backgroundColor: Colors.white,
        type: BottomNavigationBarType.fixed,
        onTap: _onNavTap,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.dashboard_outlined),
            label: "Dashboard",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.shopping_cart_outlined),
            label: "Keranjang",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.history),
            label: "Riwayat",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person_outline),
            label: "Profil",
          ),
        ],
      ),
    );
  }
}
