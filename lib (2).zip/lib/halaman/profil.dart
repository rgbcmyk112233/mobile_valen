import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../tema/warna.dart';
import '../layanan/auth_service.dart';
import '../database/db_helper.dart';
import 'login.dart';

class ProfilScreen extends StatefulWidget {
  const ProfilScreen({super.key});

  @override
  State<ProfilScreen> createState() => _ProfilScreenState();
}

class _ProfilScreenState extends State<ProfilScreen> {
  String userName = "";
  String userEmail = "";

  @override
  void initState() {
    super.initState();
    loadUserData();
  }

  Future<void> loadUserData() async {
    final prefs = await SharedPreferences.getInstance();
    final email = prefs.getString('logged_email');

    if (email != null) {
      final user = await DatabaseHelper.instance.getUserByEmail(email);
      if (user != null) {
        setState(() {
          userName = user["nama"] ?? "";
          userEmail = user["email"] ?? "";
        });
      }
    }
  }

  Future<void> _logout() async {
    await AuthService().logout();

    if (!mounted) return;
    
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => const LoginScreen()),
      (route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: WarnaTema.softGrey,
      appBar: AppBar(
        title: const Text("Profil"),
        backgroundColor: WarnaTema.oceanBlue,
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 20),

            Text(
              "Akun Saya",
              style: TextStyle(
                fontSize: 22,
                color: WarnaTema.pirateBlack,
              ),
            ),

            const SizedBox(height: 12),

            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Nama:", style: TextStyle(color: Colors.grey[700])),
                  Text(userName, style: const TextStyle(fontSize: 18)),

                  const SizedBox(height: 10),

                  Text("Email:", style: TextStyle(color: Colors.grey[700])),
                  Text(userEmail, style: const TextStyle(fontSize: 16)),
                ],
              ),
            ),

            const Spacer(),

            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _logout,
                style: ElevatedButton.styleFrom(
                  backgroundColor: WarnaTema.strawHatRed,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: const Text("Logout", style: TextStyle(fontSize: 16)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
