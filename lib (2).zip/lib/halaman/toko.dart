import 'package:flutter/material.dart';
import '../tema/warna.dart';
import '../layanan/api_produk.dart';
import 'detail_produk.dart';

class TokoScreen extends StatelessWidget {
  final String brand;
  const TokoScreen({super.key, required this.brand});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: WarnaTema.softGrey,
      body: SafeArea(
        child: Column(
          children: [

            // ✅ HEADER SAMA KAYA BERANDA + tombol kembali
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Image.asset(
                        "assets/gambar/logo.png",
                        height: 45,
                      ),
                      const SizedBox(width: 10),
                      Spacer(),
                      const Text(
                        "NakaMerch",
                        style: TextStyle(
                          fontSize: 22,
                          color: WarnaTema.oceanBlue,
                          letterSpacing: 1.2,
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 6),
                  const Divider(thickness: 1, color: Colors.black12),

                  // 🔙 tombol kembali
                  TextButton.icon(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.arrow_back_rounded, color: WarnaTema.pirateBlack),
                    label: const Text(
                      "Kembali",
                      style: TextStyle(
                        color: WarnaTema.pirateBlack,
                        fontSize: 16,
                      ),
                    ),
                  ),

                  Text(
                    brand,
                    style: const TextStyle(
                      fontSize: 20,
                      color: WarnaTema.pirateBlack,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 10),

            // ✅ LIST PRODUK BRAND TERKAIT
            Expanded(
              child: FutureBuilder<List<Produk>>(
                future: ApiProduk.ambilProduk(),
                builder: (context, snap) {
                  if (snap.connectionState == ConnectionState.waiting) {
                    return const Center(child: CircularProgressIndicator());
                  }

                  if (snap.hasError) {
                    return Center(child: Text("Error: ${snap.error}"));
                  }

                  // Filter produk berdasarkan brand
                  final list = snap.data!
                      .where((p) => (p.kolaborasi ?? '').toLowerCase() ==
                          brand.toLowerCase())
                      .toList();

                  if (list.isEmpty) {
                    return Center(child: Text("Belum ada produk untuk $brand"));
                  }

                  return GridView.builder(
                    padding: const EdgeInsets.all(12),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      childAspectRatio: 0.75,
                      crossAxisSpacing: 10,
                      mainAxisSpacing: 10,
                    ),
                    itemCount: list.length,
                    itemBuilder: (context, i) {
                      final p = list[i];

                      return GestureDetector(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => DetailProduk(produk: p),
                            ),
                          );
                        },
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(12),
                                child: Image.network(
                                  p.gambar,
                                  width: double.infinity,
                                  fit: BoxFit.cover,
                                  errorBuilder: (c, e, s) =>
                                      Container(color: Colors.grey[300]),
                                ),
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              p.namaProduk,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            Text("Rp ${p.harga}"),
                          ],
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
