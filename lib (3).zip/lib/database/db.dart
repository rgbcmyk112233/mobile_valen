import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DB {
  static Database? _db;

  static Future<Database> instance() async {
    if (_db != null) return _db!;
    _db = await _initDB();
    return _db!;
  }

  static Future<Database> _initDB() async {
    final path = join(await getDatabasesPath(), "nakamerch.db");

    return await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        // Table Users
        await db.execute("""
          CREATE TABLE users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nama TEXT,
            email TEXT UNIQUE,
            password TEXT,
            tanggal_daftar TEXT
          )
        """);

        // Table Cart
        await db.execute("""
          CREATE TABLE cart (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            produk_id TEXT,
            nama_produk TEXT,
            harga REAL,
            jumlah INTEGER,
            gambar TEXT
          )
        """);

        // Table Orders
        await db.execute("""
          CREATE TABLE orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            total REAL,
            tanggal TEXT
          )
        """);

        // Table Order Items
        await db.execute("""
          CREATE TABLE order_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id INTEGER,
            produk_id TEXT,
            nama_produk TEXT,
            harga REAL,
            jumlah INTEGER,
            gambar TEXT
          )
        """);
      },
    );
  }
}
