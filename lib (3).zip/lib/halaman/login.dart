// lib/halaman/login.dart
import 'package:flutter/material.dart';
import '../layanan/auth_service.dart';
import 'navbar.dart';
import 'register.dart';

class LoginScreen extends StatefulWidget {
  final VoidCallback? onLoginSuccess;

  const LoginScreen({super.key, this.onLoginSuccess});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final emailC = TextEditingController();
  final passC = TextEditingController();
  final _auth = AuthService();
  bool loading = false;

  void _login() async {
    setState(() => loading = true);

    bool ok = await _auth.login(emailC.text.trim(), passC.text);

    setState(() => loading = false);

    if (ok) {
      // Jika login dipanggil dari halaman lain (callback), panggil callback.
      if (widget.onLoginSuccess != null) {
        widget.onLoginSuccess!();
        if (!mounted) return;
        Navigator.pop(context);
        return;
      }

      // Login biasa -> masuk ke dashboard (BottomNav)
      if (!mounted) return;
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (_) => const BottomNav()),
        (route) => false,
      );
    } else {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Email atau password salah")),
      );
    }
  }

  @override
  void dispose() {
    emailC.dispose();
    passC.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text("Login", style: TextStyle(fontSize: 28)),
            TextField(controller: emailC, decoration: const InputDecoration(labelText: "Email")),
            TextField(controller: passC, decoration: const InputDecoration(labelText: "Password"), obscureText: true),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: loading ? null : _login,
              child: loading ? const CircularProgressIndicator(color: Colors.white) : const Text("Masuk"),
            ),
            TextButton(
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const RegisterScreen()),
              ),
              child: const Text("Belum punya akun? Daftar"),
            )
          ],
        ),
      ),
    );
  }
}
