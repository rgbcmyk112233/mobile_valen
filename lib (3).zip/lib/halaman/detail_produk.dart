import 'package:flutter/material.dart';
import '../tema/warna.dart';
import '../layanan/api_produk.dart';
import '../layanan/local_service.dart';
import '../layanan/keranjang_item.dart';
import 'keranjang.dart';
import 'login.dart';

class DetailProduk extends StatefulWidget {
  final Produk produk;
  const DetailProduk({super.key, required this.produk});

  @override
  State<DetailProduk> createState() => _DetailProdukState();
}

class _DetailProdukState extends State<DetailProduk> {
  static const double _idrPerUsd = 15500.0;
  static const double _idrPerJpy = 110.0;

  String selectedCurrency = "IDR";

  String _formatPrice(int harga) {
    final double idr = harga.toDouble();
    if (selectedCurrency == "USD") {
      return "\$${(idr / _idrPerUsd).toStringAsFixed(2)}";
    } else if (selectedCurrency == "JPY") {
      return "¥${(idr / _idrPerJpy).toStringAsFixed(0)}";
    }
    return "Rp ${idr.toStringAsFixed(0)}";
  }

  Future<bool> _ensureLoggedIn() async {
    final isLogin = await LocalService.isLoggedIn();
    if (isLogin) return true;

    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const LoginScreen()),
    );

    return await LocalService.isLoggedIn();
  }

  Future<void> _addToCart(int qty) async {
    final keranjang = await LocalService.loadKeranjang();

    final idx = keranjang.indexWhere(
      (x) => x.nama == widget.produk.namaProduk && x.gambar == widget.produk.gambar,
    );

    if (idx >= 0) {
      keranjang[idx].jumlah += qty;
    } else {
      keranjang.add(
        KeranjangItem(
          nama: widget.produk.namaProduk,
          gambar: widget.produk.gambar,
          jumlah: qty,
          harga: widget.produk.harga.toDouble(),
          dipilih: true,
        ),
      );
    }

    await LocalService.saveKeranjang(keranjang);
  }

  Future<void> _showQtyModal({required bool goToCart}) async {
    if (!(await _ensureLoggedIn())) return;

    int jumlah = 1;

    await showModalBottomSheet(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (_, setStateModal) => SizedBox(
          height: 230,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(widget.produk.namaProduk, style: const TextStyle(fontSize: 18)),
              const SizedBox(height: 12),

              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  IconButton(
                    icon: const Icon(Icons.remove_circle_outline),
                    onPressed: () {
                      if (jumlah > 1) setStateModal(() => jumlah--);
                    },
                  ),
                  Text("$jumlah", style: const TextStyle(fontSize: 18)),
                  IconButton(
                    icon: const Icon(Icons.add_circle_outline),
                    onPressed: () => setStateModal(() => jumlah++),
                  ),
                ],
              ),

              const SizedBox(height: 12),

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.grey[300]),
                    onPressed: () async {
                      await _addToCart(jumlah);
                      if (!mounted) return;
                      Navigator.pop(context);
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text("Berhasil ditambahkan ✅")),
                      );
                    },
                    child: const Text("Tambah Keranjang", style: TextStyle(color: Colors.black)),
                  ),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(backgroundColor: WarnaTema.oceanBlue),
                    onPressed: () async {
                      await _addToCart(jumlah);
                      if (!mounted) return;
                      Navigator.pop(context);
                      Navigator.push(context,
                        MaterialPageRoute(builder: (_) => const KeranjangScreen()),
                      );
                    },
                    child: const Text("Beli Sekarang", style: TextStyle(color: Colors.white)),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Row(
                children: [
                  InkWell(
                    onTap: () => Navigator.pop(context),
                    child: Image.asset("assets/gambar/logo.png", height: 40),
                  ),
                  const Spacer(),
                  IconButton(
                    icon: const Icon(Icons.shopping_cart_outlined, color: WarnaTema.pirateBlack),
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const KeranjangScreen()),
                    ),
                  )
                ],
              ),
            ),

            Container(height: 1, color: Colors.grey[300]),

            Align(
              alignment: Alignment.centerLeft,
              child: IconButton(
                icon: const Icon(Icons.arrow_back),
                onPressed: () => Navigator.pop(context),
              ),
            ),

            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [

                    Center(
                      child: Text(
                        "${widget.produk.kolaborasi} x One Piece",
                        style: const TextStyle(fontSize: 18, color: WarnaTema.oceanBlue),
                      ),
                    ),

                    const SizedBox(height: 12),

                    Container(
                      height: 270,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        image: DecorationImage(
                          image: NetworkImage(widget.produk.gambar),
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),

                    const SizedBox(height: 12),

                    Text(widget.produk.namaProduk,
                        style: const TextStyle(fontSize: 22, color: WarnaTema.oceanBlue)),

                    const SizedBox(height: 4),

                    Row(children: [
                      const Icon(Icons.location_pin, size: 18, color: Colors.red),
                      const SizedBox(width: 4),
                      Text(widget.produk.lokasi),
                    ]),

                    const SizedBox(height: 8),

                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          _formatPrice(widget.produk.harga),
                          style: const TextStyle(fontSize: 22, color: WarnaTema.pirateBlack),
                        ),

                        DropdownButton<String>(
                          value: selectedCurrency,
                          items: const [
                            DropdownMenuItem(value: "IDR", child: Text("IDR")),
                            DropdownMenuItem(value: "USD", child: Text("USD")),
                            DropdownMenuItem(value: "JPY", child: Text("JPY")),
                          ],
                          onChanged: (v) => setState(() => selectedCurrency = v!),
                        ),
                      ],
                    ),

                    const SizedBox(height: 16),

                    const Text("Deskripsi:",
                        style: TextStyle(fontSize: 18, color: WarnaTema.oceanBlue)),
                    const SizedBox(height: 6),
                    Text(widget.produk.deskripsi, style: const TextStyle(fontSize: 16)),
                  ],
                ),
              ),
            ),

            Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  Expanded(
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.grey[300]),
                      onPressed: () => _showQtyModal(goToCart: false),
                      child: const Text("Tambah Keranjang", style: TextStyle(color: Colors.black)),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(backgroundColor: WarnaTema.oceanBlue),
                      onPressed: () => _showQtyModal(goToCart: true),
                      child: const Text("Beli Sekarang", style: TextStyle(color: Colors.white)),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
