// lib/halaman/register.dart
import 'package:flutter/material.dart';
import '../layanan/auth_service.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final namaC = TextEditingController();
  final emailC = TextEditingController();
  final passC = TextEditingController();
  final _auth = AuthService();
  bool loading = false;

  void _register() async {
    setState(() => loading = true);
    bool ok = await _auth.register(namaC.text.trim(), emailC.text.trim(), passC.text);
    setState(() => loading = false);

    if (ok) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Registrasi berhasil. Kamu sudah login.")));
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (_) => const Scaffold(body: Center(child: Text("Masuk ke app...")))),
        (route) => false,
      );
    } else {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Email sudah terdaftar")));
    }
  }

  @override
  void dispose() {
    namaC.dispose();
    emailC.dispose();
    passC.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Register")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(controller: namaC, decoration: const InputDecoration(labelText: "Nama")),
            TextField(controller: emailC, decoration: const InputDecoration(labelText: "Email")),
            TextField(controller: passC, decoration: const InputDecoration(labelText: "Password"), obscureText: true),
            const SizedBox(height: 12),
            ElevatedButton(onPressed: loading ? null : _register, child: loading ? const CircularProgressIndicator() : const Text("Daftar"))
          ],
        ),
      ),
    );
  }
}
