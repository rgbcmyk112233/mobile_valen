import 'package:flutter/material.dart';
import '../tema/warna.dart';
import '../layanan/local_service.dart';
import '../layanan/keranjang_item.dart';

class KeranjangScreen extends StatefulWidget {
  const KeranjangScreen({super.key});

  @override
  State<KeranjangScreen> createState() => _KeranjangScreenState();
}

class _KeranjangScreenState extends State<KeranjangScreen> {
  List<KeranjangItem> keranjang = [];

  @override
  void initState() {
    super.initState();
    _loadKeranjang();
  }

  Future<void> _loadKeranjang() async {
    try {
      final items = await LocalService.loadKeranjang();
      setState(() {
        keranjang = items;
      });
    } catch (e) {
      debugPrint("❌ Error load keranjang: $e");
    }
  }

  Future<void> updateStorage() async {
    await LocalService.saveKeranjang(keranjang);
  }

  double getTotal() {
    double total = 0;
    for (var item in keranjang) {
      if (item.dipilih) {
        total += item.harga * item.jumlah;
      }
    }
    return total;
  }

  String formatRupiah(double angka) {
    return "Rp ${angka.toStringAsFixed(0)}";
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 1,
        title: const Text(
          "Keranjang",
          style: TextStyle(color: WarnaTema.pirateBlack),
        ),
      ),

      backgroundColor: Colors.white,

      body: keranjang.isEmpty
          ? const Center(
              child: Text(
                "Keranjang masih kosong",
                style: TextStyle(fontSize: 16),
              ),
            )
          : ListView.builder(
              itemCount: keranjang.length,
              itemBuilder: (_, i) {
                final item = keranjang[i];

                return Card(
                  color: Colors.white,
                  margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  child: ListTile(
                    leading: Image.network(
                      item.gambar,
                      width: 60,
                      height: 60,
                      fit: BoxFit.cover,
                    ),
                    title: Text(item.nama),
                    subtitle: Text(
                      "${formatRupiah(item.harga)} x ${item.jumlah}",
                      style: const TextStyle(fontSize: 14),
                    ),

                    trailing: Checkbox(
                      value: item.dipilih,
                      onChanged: (v) async {
                        setState(() => item.dipilih = v!);
                        await updateStorage();
                      },
                    ),

                    onTap: () async {
                      await showModalBottomSheet(
                        context: context,
                        backgroundColor: Colors.white,
                        builder: (c) => SizedBox(
                          height: 180,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(item.nama, style: const TextStyle(fontSize: 18)),
                              const SizedBox(height: 10),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  IconButton(
                                    onPressed: () async {
                                      if (item.jumlah > 1) {
                                        setState(() => item.jumlah--);
                                        await updateStorage();
                                      }
                                    },
                                    icon: const Icon(Icons.remove_circle_outline),
                                  ),
                                  Text("${item.jumlah}", style: const TextStyle(fontSize: 18)),
                                  IconButton(
                                    onPressed: () async {
                                      setState(() => item.jumlah++);
                                      await updateStorage();
                                    },
                                    icon: const Icon(Icons.add_circle_outline),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 8),
                              ElevatedButton(
                                style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                                onPressed: () async {
                                  setState(() => keranjang.removeAt(i));
                                  await updateStorage();
                                  Navigator.pop(context);
                                },
                                child: const Text("Hapus dari Keranjang"),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                );
              },
            ),

      bottomNavigationBar: Container(
        padding: const EdgeInsets.all(12),
        color: Colors.white,
        child: ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: WarnaTema.oceanBlue,
            padding: const EdgeInsets.symmetric(vertical: 14),
          ),
          onPressed: () {
            if (getTotal() == 0) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text("Pilih produk dulu ya 😄")),
              );
            }
          },
          child: Text(
            "Checkout ${formatRupiah(getTotal())}",
            style: const TextStyle(fontSize: 18, color: Colors.white),
          ),
        ),
      ),
    );
  }
}
