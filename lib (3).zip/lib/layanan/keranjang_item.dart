// lib/layanan/keranjang_item.dart
class KeranjangItem {
  String nama;
  String gambar;
  int jumlah;
  double harga;
  bool dipilih;

  KeranjangItem({
    required this.nama,
    required this.gambar,
    required this.jumlah,
    required this.harga,
    this.dipilih = true,
  });

  /// Convert object -> Map (dipakai saat simpan ke SharedPreferences)
  Map<String, dynamic> toMap() {
    return {
      "nama": nama,
      "gambar": gambar,
      "jumlah": jumlah,
      "harga": harga,
      "dipilih": dipilih,
    };
  }

  /// Buat object dari Map (dipakai saat load dari SharedPreferences)
  factory KeranjangItem.fromMap(Map<String, dynamic> map) {
    return KeranjangItem(
      nama: map["nama"] ?? "",
      gambar: map["gambar"] ?? "",
      jumlah: (map["jumlah"] is int)
          ? map["jumlah"]
          : int.tryParse(map["jumlah"].toString()) ?? 1,
      harga: (map["harga"] is double)
          ? map["harga"]
          : (map["harga"] is int)
              ? (map["harga"] as int).toDouble()
              : double.tryParse(map["harga"].toString()) ?? 0.0,
      dipilih: map["dipilih"] ?? true,
    );
  }
}
