import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'keranjang_item.dart';

class LocalService {
  // ✅ Simpan status login & user email
  static Future<void> loginUser(String email) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool("is_logged_in", true);
    await prefs.setString("current_user", email);
  }

  static Future<bool> isLoggedIn() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool("is_logged_in") ?? false;
  }

  static Future<String?> getCurrentUser() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString("current_user");
  }

  static Future<void> logoutUser() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool("is_logged_in", false);
    await prefs.remove("current_user");
  }

  // ✅ Key keranjang sesuai user
  static Future<String?> _cartKey() async {
    final email = await getCurrentUser();
    if (email == null) return null;
    return "cart_$email";
  }

  // ✅ Simpan keranjang
  static Future<void> saveKeranjang(List<KeranjangItem> keranjang) async {
    final prefs = await SharedPreferences.getInstance();
    final key = await _cartKey();
    if (key == null) return;

    List<String> data =
        keranjang.map((item) => jsonEncode(item.toMap())).toList();

    await prefs.setStringList(key, data);
  }

  // ✅ Ambil keranjang
  static Future<List<KeranjangItem>> loadKeranjang() async {
    final prefs = await SharedPreferences.getInstance();
    final key = await _cartKey();
    if (key == null) return [];

    List<String>? data = prefs.getStringList(key);
    if (data == null) return [];

    return data
        .map((e) => KeranjangItem.fromMap(jsonDecode(e)))
        .toList();
  }

  // ✅ Tambah item ke keranjang (merge qty)
  static Future<void> addToKeranjang(KeranjangItem item) async {
    final keranjang = await loadKeranjang();

    final idx = keranjang.indexWhere((x) => x.nama == item.nama);

    if (idx >= 0) {
      keranjang[idx].jumlah += item.jumlah;
    } else {
      keranjang.add(item);
    }

    await saveKeranjang(keranjang);
  }

  static Future<void> clearKeranjang() async {
    final prefs = await SharedPreferences.getInstance();
    final key = await _cartKey();
    if (key == null) return;
    await prefs.remove(key);
  }
}
