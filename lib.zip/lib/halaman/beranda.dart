import 'package:flutter/material.dart';
import 'package:nakamerch/halaman/toko.dart';
import '../tema/warna.dart';
import '../layanan/api_produk.dart';

class BerandaScreen extends StatefulWidget {
  const BerandaScreen({super.key});

  @override
  State<BerandaScreen> createState() => _BerandaScreenState();
}

class _BerandaScreenState extends State<BerandaScreen> {
  late Future<List<Produk>> _daftarProduk;
  String searchQuery = "";
  double hargaMax = 999999999;

  @override
  void initState() {
    super.initState();
    _daftarProduk = ApiProduk.ambilProduk();
  }

  List<Widget> _buildBrandSections(List<Produk> produkList) {
    final Map<String, List<Produk>> grouped = {};

    for (var p in produkList) {
      final brand = p.kolaborasi.isNotEmpty ? p.kolaborasi : 'Unknown';
      grouped.putIfAbsent(brand, () => []);
      grouped[brand]!.add(p);
    }

    List<Widget> sections = [];

    grouped.forEach((brand, items) {
      final tampil = items.take(4).toList();

      sections.add(
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4.0),
              child: Text(
                brand,
                style: const TextStyle(
                  fontSize: 20,
                  color: WarnaTema.pirateBlack,
                ),
              ),
            ),
            const SizedBox(height: 10),

            SizedBox(
              height: 150,
              child: Row(
                children: List.generate(tampil.length, (i) {
                  final produk = tampil[i];

                  return Expanded(
                    child: GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => TokoScreen(),
                          ),
                        );
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(4.0),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(14),
                          child: Image.network(
                            produk.gambar,
                            fit: BoxFit.cover,
                            width: double.infinity,
                            height: double.infinity,
                            errorBuilder: (c, e, s) =>
                                Container(color: Colors.grey[300]),
                          ),
                        ),
                      ),
                    ),
                  );
                }),
              ),
            ),

            const SizedBox(height: 22),
          ],
        ),
      );
    });

    return sections;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: WarnaTema.softGrey,

      // ✅ HEADER STAY FIXED
      appBar: AppBar(
        elevation: 1,
        backgroundColor: Colors.white,
        automaticallyImplyLeading: false,
        title: Row(
          children: [
            Image.asset(
              "assets/gambar/logo.png",
              height: 32,
            ),
            const SizedBox(width: 10),
            const Text(
              "NakaMerch",
              style: TextStyle(
                fontSize: 22,
                color: WarnaTema.oceanBlue,
                letterSpacing: 1.2,
              ),
            ),
          ],
        ),
      ),

      body: FutureBuilder<List<Produk>>(
        future: _daftarProduk,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(
              child: Text(
                "Gagal memuat data 😢",
                style: TextStyle(color: WarnaTema.strawHatRed),
              ),
            );
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text("Tidak ada produk ditemukan."));
          }

          var produkList = snapshot.data!;

          if (searchQuery.isNotEmpty) {
            produkList = produkList
                .where((p) => p.namaProduk.toLowerCase().contains(
                      searchQuery.toLowerCase(),
                    ))
                .toList();
          }

          produkList = produkList.where((p) => p.harga <= hargaMax).toList();

          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: ListView(
              children: [
                const SizedBox(height: 12),

                const Divider(thickness: 1, color: Colors.black12),

                const SizedBox(height: 6),
                const Text(
                  "Hai, Valentina 👋",
                  style: TextStyle(
                    fontSize: 18,
                    color: WarnaTema.pirateBlack,
                  ),
                ),

                const SizedBox(height: 14),

                // ✅ Search + Filter dalam 1 baris
                Row(
                  children: [
                    Expanded(
                      flex: 3,
                      child: TextField(
                        decoration: InputDecoration(
                          hintText: "Cari produk...",
                          prefixIcon: const Icon(Icons.search),
                          filled: true,
                          fillColor: Colors.white,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(14),
                            borderSide: BorderSide.none,
                          ),
                        ),
                        onChanged: (v) {
                          setState(() => searchQuery = v);
                        },
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      flex: 2,
                      child: DropdownButtonFormField<double>(
                        decoration: InputDecoration(
                          filled: true,
                          fillColor: Colors.white,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(14),
                            borderSide: BorderSide.none,
                          ),
                        ),
                        value: hargaMax,
                        items: const [
                          DropdownMenuItem(value: 50000, child: Text("Under 50K")),
                          DropdownMenuItem(value: 100000, child: Text("100K")),
                          DropdownMenuItem(value: 300000, child: Text("300K")),
                          DropdownMenuItem(value: 500000, child: Text("500K")),
                          DropdownMenuItem(value: 999999999, child: Text("Semua")),
                        ],
                        onChanged: (v) {
                          setState(() => hargaMax = v!);
                        },
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 20),

                const Text(
                  "Featured Drops",
                  style: TextStyle(
                    fontSize: 20,
                    color: WarnaTema.pirateBlack,
                    letterSpacing: 1,
                  ),
                ),
                const SizedBox(height: 10),

                ..._buildBrandSections(produkList),
              ],
            ),
          );
        },
      ),
    );
  }
}
