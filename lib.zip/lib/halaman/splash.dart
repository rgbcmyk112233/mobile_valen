import 'package:flutter/material.dart';
import '../tema/warna.dart';
import 'login.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 3), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const LoginScreen()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: WarnaTema.oceanBlue,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.shopping_bag_rounded,
                size: 100, color: WarnaTema.goldPirate),
            const SizedBox(height: 20),
            Text(
              'NAKAMERCH',
              style: TextStyle(
                color: WarnaTema.goldPirate,
                fontSize: 32,
                letterSpacing: 3,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              'Sail Into Style!',
              style: TextStyle(
                color: WarnaTema.strawBeige,
                fontSize: 16,
              ),
            ),
            const SizedBox(height: 30),
            const CircularProgressIndicator(
              color: Colors.white,
              strokeWidth: 3,
            ),
          ],
        ),
      ),
    );
  }
}
