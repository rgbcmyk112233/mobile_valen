import 'package:flutter/material.dart';

class KeranjangScreen extends StatelessWidget {
  const KeranjangScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(child: Text("Keranjang"));
  }
}
