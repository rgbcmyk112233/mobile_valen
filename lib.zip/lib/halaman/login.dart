import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../tema/warna.dart';
import '../util/enkripsi.dart';
//import '../model/pengguna.dart';
import 'beranda.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _username = TextEditingController();
  final TextEditingController _password = TextEditingController();
  bool _isLoading = false;

  Future<void> _login() async {
    final user = _username.text.trim();
    final pass = _password.text;

    if (user.isEmpty || pass.isEmpty) {
      _tampilDialog('Login Gagal', 'Username dan password tidak boleh kosong.');
      return;
    }

    setState(() => _isLoading = true);

    try {
      final hash = Enkripsi.hashPassword(pass);
      final url = Uri.parse(
        'https://api.sheety.co/bbb8b4389560e0f66169374c4062700b/nakamerch/sheet1',
      );

      final response = await http.get(url);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final List items = data['sheet1'] ?? [];

        final match = items.firstWhere(
          (item) =>
              (item['nama'] == user || item['email'] == user) &&
              item['password'] == hash,
          orElse: () => null,
        );

        if (match != null) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => const BerandaScreen()),
          );
        } else {
          _tampilDialog('Login Gagal', 'Username atau password salah.');
        }
      } else {
        _tampilDialog('Error', 'Gagal menghubungi server (${response.statusCode}).');
      }
    } catch (e) {
      _tampilDialog('Kesalahan', 'Terjadi kesalahan: $e');
    } finally {
      setState(() => _isLoading = false);
    }
  }

  void _tampilDialog(String judul, String pesan) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(judul),
        content: Text(pesan),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: WarnaTema.strawBeige,
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 40),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset(
                'assets/gambar/logo_nakamerch.png',
                height: 120,
              ),
              const SizedBox(height: 40),
              TextField(
                controller: _username,
                decoration: const InputDecoration(
                  labelText: 'Username',
                  enabledBorder: UnderlineInputBorder(),
                  focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Colors.black),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              TextField(
                controller: _password,
                obscureText: true,
                decoration: const InputDecoration(
                  labelText: 'Password',
                  enabledBorder: UnderlineInputBorder(),
                  focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Colors.black),
                  ),
                ),
              ),
              const SizedBox(height: 40),
              _isLoading
                  ? const CircularProgressIndicator()
                  : ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: WarnaTema.oceanBlue,
                        padding: const EdgeInsets.symmetric(
                            horizontal: 40, vertical: 10),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(6)),
                      ),
                      onPressed: _login,
                      child: const Text(
                        'Sign In',
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.white,
                        ),
                      ),
                    ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text('Belum punya akun ya?'),
                  TextButton(
                    onPressed: () {
                      Navigator.pushNamed(context, '/register');
                    },
                    child: const Text(
                      'Sign Up duluu',
                      style: TextStyle(
                        color: Colors.black,
                      ),
                    ),
                  )
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
