import 'package:flutter/material.dart';
import '../tema/warna.dart';
import '../layanan/api_produk.dart';

class DetailProduk extends StatelessWidget {
  final Produk produk;

  const DetailProduk({super.key, required this.produk});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,

      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 1,
        title: Text(
          produk.namaProduk,
          style: const TextStyle(
            color: WarnaTema.oceanBlue,
          ),
        ),
        centerTitle: true,
        iconTheme: const IconThemeData(color: WarnaTema.oceanBlue),
      ),

      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ✅ Foto produk
            AspectRatio(
              aspectRatio: 1,
              child: Image.network(
                produk.gambar,
                width: double.infinity,
                fit: BoxFit.cover,
                errorBuilder: (c, e, s) =>
                    Container(color: Colors.grey[200], child: const Center(child: Icon(Icons.error))),
              ),
            ),

            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // ✅ Nama Produk
                  Text(
                    produk.namaProduk,
                    style: const TextStyle(
                        fontSize: 22,
                    ),
                  ),
                  const SizedBox(height: 5),

                  // ✅ Harga
                  Text(
                    "Rp ${produk.harga}",
                    style: const TextStyle(
                      fontSize: 20,
                      color: Colors.black87,
                    ),
                  ),
                  const SizedBox(height: 14),

                  // ✅ Informasi Kolaborasi
                  if (produk.kolaborasi != null)
                    Text(
                      "Kolaborasi: ${produk.kolaborasi}",
                      style: TextStyle(color: Colors.grey[700]),
                    ),

                  const SizedBox(height: 20),

                  // ✅ Deskripsi Placeholder (kalau gak ada di API)
                  const Text(
                    "Deskripsi Produk",
                    style: TextStyle(fontSize: 18),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    produk.deskripsi ?? "Belum ada deskripsi.",
                    style: TextStyle(fontSize: 14, color: Colors.grey[800]),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),

      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(14),
        child: SizedBox(
          height: 52,
          child: ElevatedButton(
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text("Ditambahkan ke keranjang (dummy)"))
              );
              // nanti kita ganti biar masuk cart beneran
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: WarnaTema.oceanBlue,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            child: const Text(
              "Tambah ke Keranjang",
              style: TextStyle(fontSize: 16, color: Colors.white),
            ),
          ),
        ),
      ),
    );
  }
}
