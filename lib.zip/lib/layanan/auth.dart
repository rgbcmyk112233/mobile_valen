/*import 'package:flutter/material.dart';
import '../layanan/auth.dart';
import '../halaman/login.dart';

class DetailProdukScreen extends StatelessWidget {
  final Map<String, dynamic> produk;
  const DetailProdukScreen({super.key, required this.produk});

  Future<void> _tambahKeranjang(BuildContext context) async {
    final user = await AuthLayanan.ambilLogin();

    if (user == null) {
      // Belum login, arahkan ke login
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Belum Login'),
          content: const Text(
              'Kamu harus login dulu sebelum bisa menambah ke keranjang.'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const LoginScreen()),
                );
              },
              child: const Text('Login Sekarang'),
            ),
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Batal'),
            ),
          ],
        ),
      );
    } else {
      // Sudah login → tambahkan ke keranjang
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('${produk['nama']} berhasil ditambahkan ke keranjang!'),
          duration: const Duration(seconds: 2),
        ),
      );
      // logika simpan ke list keranjang bisa ditambahkan di sini
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(produk['nama'] ?? 'Detail Produk')),
      body: Column(
        children: [
          Image.network(produk['gambar'] ?? ''),
          const SizedBox(height: 10),
          Text(produk['nama'] ?? '', style: const TextStyle(fontSize: 20)),
          Text(produk['harga'] ?? '', style: const TextStyle(fontSize: 16)),
          const SizedBox(height: 20),
          ElevatedButton(
            onPressed: () => _tambahKeranjang(context),
            child: const Text('Tambah ke Keranjang'),
          ),
        ],
      ),
    );
  }
} */
