import 'package:flutter/material.dart';
import 'package:nakamerch/halaman/navbar.dart';
import 'tema/warna.dart';

void main() {
  runApp(const NakaMerchApp());
}

class NakaMerchApp extends StatelessWidget {
  const NakaMerchApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'NAKAMERCH',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.light(
          primary: WarnaTema.oceanBlue,
          secondary: WarnaTema.goldPirate,
          surface: WarnaTema.strawBeige,
          error: WarnaTema.strawHatRed,
        ),
        scaffoldBackgroundColor: WarnaTema.strawBeige,
        fontFamily: 'Poppins',
        appBarTheme: AppBarTheme(
          backgroundColor: WarnaTema.oceanBlue,
          foregroundColor: Colors.white,
          elevation: 2,
          titleTextStyle: const TextStyle(
            fontSize: 20,
          ),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: WarnaTema.oceanBlue,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            textStyle: const TextStyle(
              fontSize: 16,
            ),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          labelStyle: TextStyle(color: WarnaTema.pirateBlack),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: WarnaTema.oceanBlue, width: 2),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: WarnaTema.skyWhite, width: 1),
          ),
        ),
      ),
      home: const BottomNav(), // ✅ masuk beranda dulu
    );
  }
}
